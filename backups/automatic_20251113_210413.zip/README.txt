Local Backup
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Created: 2025-11-13 21:04:13
User ID: 850786361572720661
Type: Automatic
Contains: All SQLite database files
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

To restore:
1. Extract this ZIP file
2. Replace your db/ folder contents with these files
3. Restart the bot

🤖 WOS Discord Bot Backup System
